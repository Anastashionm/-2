﻿using Microsoft.SqlServer.Server;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CatEars
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            #region Лет
            AgeRealYearsCat.Items.Add("1");
            AgeRealYearsCat.Items.Add("2");
            AgeRealYearsCat.Items.Add("3");
            AgeRealYearsCat.Items.Add("4");
            AgeRealYearsCat.Items.Add("5");
            AgeRealYearsCat.Items.Add("6");
            AgeRealYearsCat.Items.Add("7");
            AgeRealYearsCat.Items.Add("8");
            AgeRealYearsCat.Items.Add("9");
            AgeRealYearsCat.Items.Add("10");
            AgeRealYearsCat.Items.Add("11");
            AgeRealYearsCat.Items.Add("12");
            AgeRealYearsCat.Items.Add("13");
            AgeRealYearsCat.Items.Add("14");
            AgeRealYearsCat.Items.Add("15");
            AgeRealYearsCat.Items.Add("16");
            AgeRealYearsCat.Items.Add("17");
            AgeRealYearsCat.Items.Add("18");
            AgeRealYearsCat.Items.Add("19");
            AgeRealYearsCat.Items.Add("20");
            AgeRealYearsCat.Items.Add("21");
            AgeRealYearsCat.Items.Add("22");
            AgeRealYearsCat.Items.Add("23");
            #endregion
            #region Месяцев
            AgeRealMonthCat.Items.Add("1");
            AgeRealMonthCat.Items.Add("2");
            AgeRealMonthCat.Items.Add("3");
            AgeRealMonthCat.Items.Add("4");
            AgeRealMonthCat.Items.Add("5");
            AgeRealMonthCat.Items.Add("6");
            AgeRealMonthCat.Items.Add("7");
            AgeRealMonthCat.Items.Add("8");
            AgeRealMonthCat.Items.Add("9");
            AgeRealMonthCat.Items.Add("10");
            AgeRealMonthCat.Items.Add("11");
            AgeRealMonthCat.Items.Add("12");
            #endregion

        }

        private void button1_Click(object sender, EventArgs e)
        {
            byte realyearsCat = Convert.ToByte(AgeRealYearsCat.Text);
            byte realMonthCat = Convert.ToByte(AgeRealMonthCat.Text);

            double yearsCat = (realyearsCat + Convert.ToDouble(realMonthCat) /12.00) * 7;
            double monthCat = yearsCat * 12;

            /*double q = realyearsCat * 7;
            double w = realMonthCat * 7;*/

            string ys = Convert.ToString(yearsCat);
            string y = Convert.ToString((ys)[0]);
            string y2 = Convert.ToString((ys)[1]);
            int yi = Convert.ToInt32(y + y2);

            int catEars = 0;

            if (monthCat % 12 == 0)
            {
                realyearsCat++;
                realMonthCat = 0;
            }
            else
            {
                AgeYearsCat.Text = Convert.ToString(yi);
                double m = (yearsCat - yi) * 12;

                AgeMonthCat.Text = Convert.ToString(String.Format("{0:0}", m));

                //catEars = realMonthCat / 12;
            }


            //AgeYearsCat.Text = Convert.ToString(monthCat);
            //AgeMonthCat.Text = Convert.ToString(yi);
        }
    }
}
