﻿namespace CatEars
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.AgeRealYearsCat = new System.Windows.Forms.ComboBox();
            this.AgeRealMonthCat = new System.Windows.Forms.ComboBox();
            this.label = new System.Windows.Forms.Label();
            this.лет = new System.Windows.Forms.Label();
            this.месяцев = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.AgeMonthCat = new System.Windows.Forms.TextBox();
            this.AgeYearsCat = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.q1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // AgeRealYearsCat
            // 
            this.AgeRealYearsCat.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.AgeRealYearsCat.FormattingEnabled = true;
            this.AgeRealYearsCat.Location = new System.Drawing.Point(127, 104);
            this.AgeRealYearsCat.Name = "AgeRealYearsCat";
            this.AgeRealYearsCat.Size = new System.Drawing.Size(121, 28);
            this.AgeRealYearsCat.TabIndex = 0;
            // 
            // AgeRealMonthCat
            // 
            this.AgeRealMonthCat.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.AgeRealMonthCat.FormattingEnabled = true;
            this.AgeRealMonthCat.Location = new System.Drawing.Point(372, 104);
            this.AgeRealMonthCat.Name = "AgeRealMonthCat";
            this.AgeRealMonthCat.Size = new System.Drawing.Size(121, 28);
            this.AgeRealMonthCat.TabIndex = 1;
            // 
            // label
            // 
            this.label.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label.Location = new System.Drawing.Point(28, 92);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(93, 44);
            this.label.TabIndex = 2;
            this.label.Text = "Возраст кошки";
            // 
            // лет
            // 
            this.лет.AutoSize = true;
            this.лет.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.лет.Location = new System.Drawing.Point(292, 104);
            this.лет.Name = "лет";
            this.лет.Size = new System.Drawing.Size(37, 20);
            this.лет.TabIndex = 3;
            this.лет.Text = "лет";
            // 
            // месяцев
            // 
            this.месяцев.AutoSize = true;
            this.месяцев.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.месяцев.Location = new System.Drawing.Point(522, 102);
            this.месяцев.Name = "месяцев";
            this.месяцев.Size = new System.Drawing.Size(73, 20);
            this.месяцев.TabIndex = 4;
            this.месяцев.Text = "месяцев";
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(29, 203);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(92, 45);
            this.label4.TabIndex = 5;
            this.label4.Text = "Кошачьих лет";
            // 
            // AgeMonthCat
            // 
            this.AgeMonthCat.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.AgeMonthCat.Location = new System.Drawing.Point(372, 216);
            this.AgeMonthCat.Name = "AgeMonthCat";
            this.AgeMonthCat.Size = new System.Drawing.Size(100, 29);
            this.AgeMonthCat.TabIndex = 6;
            // 
            // AgeYearsCat
            // 
            this.AgeYearsCat.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.AgeYearsCat.Location = new System.Drawing.Point(127, 216);
            this.AgeYearsCat.Name = "AgeYearsCat";
            this.AgeYearsCat.Size = new System.Drawing.Size(121, 29);
            this.AgeYearsCat.TabIndex = 7;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.Location = new System.Drawing.Point(522, 216);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(73, 20);
            this.label6.TabIndex = 9;
            this.label6.Text = "месяцев";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(282, 216);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 20);
            this.label1.TabIndex = 10;
            this.label1.Text = "лет";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(245, 300);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(125, 40);
            this.button1.TabIndex = 11;
            this.button1.Text = "Расчитать";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // q1
            // 
            this.q1.AutoSize = true;
            this.q1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.q1.Location = new System.Drawing.Point(522, 345);
            this.q1.Name = "q1";
            this.q1.Size = new System.Drawing.Size(37, 20);
            this.q1.TabIndex = 12;
            this.q1.Text = "лет";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.q1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.AgeYearsCat);
            this.Controls.Add(this.AgeMonthCat);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.месяцев);
            this.Controls.Add(this.лет);
            this.Controls.Add(this.label);
            this.Controls.Add(this.AgeRealMonthCat);
            this.Controls.Add(this.AgeRealYearsCat);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox AgeRealYearsCat;
        private System.Windows.Forms.ComboBox AgeRealMonthCat;
        private System.Windows.Forms.Label label;
        private System.Windows.Forms.Label лет;
        private System.Windows.Forms.Label месяцев;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox AgeMonthCat;
        private System.Windows.Forms.TextBox AgeYearsCat;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label q1;
    }
}

